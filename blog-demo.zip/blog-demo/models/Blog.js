const mongoose = require('mongoose');

const blogSchema = new mongoose.Schema({
    title: String,
    description: String,
    categories: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Category' }],
    price: Number,
    featuredImage: String,
    additionalImages: [String],
    fuelType: String,
    transmission: String,
    engineSize: String,
    mileage: String,
    seatingCapacity: Number,
    size: String,
    fuelTank: String,
    year: String,  // New field
    make: String,  // New field
    bodyType: String,  // New field
    engineType: String,  // New field
    interiorMaterial: String,  // New field
    sunroof: Boolean,  // New field
    rearCamera: Boolean,  // New field
    parkingSensors: Boolean,  // New field
    cruiseControl: Boolean,  // New field
    fogLights: Boolean,  // New field
    safetyRating: Number,  // New field
    abs: Boolean,  // New field
    loanEligibility: Boolean,  // New field
    resaleValue: Number,  // New field
    insuranceCost: Number,  // New field
    maintenanceCost: Number,  // New field
    createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Blog', blogSchema);
