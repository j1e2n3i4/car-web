const express = require('express');
const path = require('path');
const connectDB = require('./config/database');
const methodOverride = require('method-override');
const bodyParser = require('body-parser');
const session = require('express-session');
const MongoStore = require('connect-mongo');
const bcrypt = require('bcrypt');
const Admin = require('./models/admin'); // Import the Admin model

// Connect to MongoDB
connectDB();

const app = express();

// Middleware
app.use(session({
    secret: 'ironman',
    resave: false,
    saveUninitialized: false,
    store: MongoStore.create({
        mongoUrl: 'mongodb://localhost:27017/blog-demo',
        collectionName: 'sessions'
    }),
    cookie: { maxAge: 60 * 60 * 1000 } // 1 hour
}));
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(methodOverride('_method'));
app.use(express.static(path.join(__dirname, 'public')));

// View Engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Authentication Middleware
function isAuthenticated(req, res, next) {
    if (req.session.isAuthenticated) {
        next();
    } else {
        res.redirect('/login');
    }
}

// Import routes
const blogRoutes = require('./routes/blogRoutes');
const categoryRoutes = require('./routes/categoryRoutes');
const vehicleRoutes = require('./routes/vehicleRoutes'); // Import vehicleRoutes

// Apply Authentication Middleware to all routes except '/vehicles' and '/login'
app.use('/blogs', isAuthenticated, blogRoutes);
app.use('/categories', isAuthenticated, categoryRoutes);
app.use('/vehicles', vehicleRoutes); // Exclude /vehicles from the authentication check

// Registration Route
app.get('/register', (req, res) => {
    res.render('register');
});

app.post('/register', async (req, res) => {
    const { username, password } = req.body;

    try {
        const admin = new Admin({ username, password });
        await admin.save();
        res.redirect('/login');
    } catch (err) {
        res.render('register', { error: 'Error registering user. Please try again.' });
    }
});

// Login Route
app.get('/login', (req, res) => {
    res.render('login');
});

app.post('/login', async (req, res) => {
    const { username, password } = req.body;

    try {
        const admin = await Admin.findOne({ username });
        if (admin && await bcrypt.compare(password, admin.password)) {
            req.session.isAuthenticated = true;
            req.session.admin = admin; // Storing the whole admin object in session
            res.redirect('/');
        } else {
            res.render('login', { error: 'Invalid username or password' });
        }
    } catch (err) {
        res.render('login', { error: 'Error logging in. Please try again.' });
    }
});

// Logout Route
app.get('/logout', (req, res) => {
    req.session.destroy(() => {
        res.redirect('/login');
    });
});

// Home Route
app.get('/', isAuthenticated, (req, res) => {
    if (req.session.admin) {
        res.render('home', { username: req.session.admin.username });
    } else {
        res.render('home', { username: null });
    }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});
